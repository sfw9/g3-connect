# G3-Soundupload: Recherche

Vertiefte statische Analyse, ergänzt um anonyme Serveranfragen am 21.10.2026. Ohne Bluetooth-Mitschnitt und ohne Schreibzugriff auf einen Roller.

- `ANALYSE.md`: Ergebnisse, Quellen und verbleibende Grenzen.
- `protocol-findings.json`: rekonstruierte Protokollfelder.
- `offline-example.json`: unabhängig berechnetes Beispiel; keine gültige G3-Slotnummer vorausgesetzt.
- `server-check.json`: echte HTTP-Versuche und deren Grenzen; keine Soundslots erhalten.
- `evidence-manifest.json`: Hashes der untersuchten Primärdateien und überprüfte Fundstellen.

Das Paket enthält keinen ausführbaren Uploader, keine Hersteller-APK, keine dekompilierten Herstellerquellen und keine Kopplungsschlüssel. Protokollbefunde sind statisch belegt; ergänzende HTTP-Ergebnisse sind separat dokumentiert. Ein erfolgreicher Upload wurde nicht am Roller getestet.

Neue HCI-Auswertung: `capture-analysis.md` und `capture-summary.json` belegen drei akzeptierte Uploads auf Slot 71. Die Ereignisbezeichnung und eine vollständige Slottabelle bleiben unbekannt.

Erfolgreiche authentifizierte Serverabfrage: `server-success.md` und `server-result.json` ordnen Slot 71 der Taste, 72 dem Alarm und 73 dem Einschalten zu. Frühere Aussagen einer unbekannten Zuordnung sind damit überholt. Keine Anmeldedaten im Export.
