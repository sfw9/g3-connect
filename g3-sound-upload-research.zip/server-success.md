# MAX G3: Serverabfrage der Sound-Einstellungen erfolgreich

Stand: 21.10.2026. Der Sound-Leseaufruf wurde mit ausdrücklicher Zustimmung des Kontoinhabers nach Anmeldung per E-Mail-Einmalcode erfolgreich ausgeführt. Ein Passwort wurde nicht benötigt. Es wurden keine Sounds hochgeladen, Einstellungen geändert oder Firmwarebefehle gesendet.

## Belegte Zuordnung

| Ereignis laut Server | Upload-Slot | Maske | Werkstonindex | Beleg |
| --- | --- | --- | --- | --- |
| `customize_sound` – Custom Button, benutzerdefinierte Taste | **71 / `0x47`** | **`0x1000`** | 8 | Serverantwort und drei bestätigte Uploads im HCI-Mitschnitt |
| `abnormal_alarm_sound` – Abnormality Alert, Alarmton | **72 / `0x48`** | **`0x2000`** | 14 | Erfolgreiche Serverantwort; hier kein eigener Hardwareupload |
| `power_on_sound` – Power On, Einschaltton | **73 / `0x49`** | **`0x4000`** | 31 | Erfolgreiche Serverantwort; hier kein eigener Hardwareupload |

Das sind die vom Server für den abgefragten Roller gelieferten Einträge. Ein eigener Ausschaltton-Eintrag wurde nicht geliefert. Die Werkstonindizes sind von den Datei-Uploadslots zu unterscheiden. Dass beim Button beide Male die Zahl 8 in anderen Zusammenhängen auftaucht, macht sie nicht zum Uploadslot: Der ist nachweislich 71.

Die Maske `0x1000` für Custom Button stimmt mit der Änderung von VCU-Register `0x1F` vor und nach dem letzten Soundupload im Mitschnitt überein. Damit ist die zuvor offene Ereignisbezeichnung von Slot 71 geklärt.

## Anfrage und Antwort nachgebildet

Die in der untersuchten APK enthaltene ARM64-Bibliothek `libnetseckit-4.3.1.so` wurde extrahiert und in einer lokalen Unicorn-Emulation ausgeführt. Der Loader berücksichtigt ELF-Relokationen und stellt die benötigten JNI-/libc-Funktionen bereit. Android-UUID- und Bytearray-Verhalten sowie die Zugriffe auf Metadaten der Original-APK sind nachvollzogen. Die SDK-Kryptofunktionen wurden nicht gepatcht.

- Native Verschlüsselung: `JNIFactory.w3270a03dafee4a0a`, Offset `0x464B4`.
- Native Entschlüsselung: `JNIFactory.w1228bcedf6204eeb`, Offset `0x46774`.
- Anfragehülle: JSON mit `d`, `h`, **`k`**, `p`, `t`.
- Antwort in dieser Untersuchung: JSON mit `v`, `s`, `r`.
- Die vom SDK verlangte RSA-Prüfung der Antwort wurde entsprechend dem Java-Code von `com.netease.NetSecKit.poly.a.f` ausgeführt und bestand; sie wurde nicht übersprungen.

Die ersten erfolgreichen SDK-Anfragen ohne Anmeldung ergaben nach Entschlüsselung `401900 / token empty`. Damit war erstmals eine echte Authentifizierungsanforderung nachgewiesen; der frühere Fehler `Undefined property: stdClass::$k` beschrieb lediglich die fehlende native Verpackung.

Die genaue serverinterne Implementierung wurde damit nicht eingesehen. Nachgebildet und gegen den Server geprüft sind der Clientaufruf und die Verarbeitung seiner Antwort. Eine unabhängige vollständige Neuimplementierung des nativen SDK-Kryptocodes wird hier nicht behauptet.

## Tatsächlich erfolgreicher Ablauf

1. Regionsabfrage über `https://api-passport-fra.ninebot.com/v5/region`: Antwort `resultCode = 90000`, Region `fra`.
2. Nach ausdrücklichem Auftrag genau einmal einen Anmeldecode über `/v4/code/email` angefordert. Kein Passwort-Reset und keine Registrierung.
3. Anmeldung mit dem vom Nutzer gelieferten Einmalcode über `/v6/user/emailCodeLogin`: `resultCode = 90000`.
4. Übergabe der Passport-Anmeldung an `https://api-jhcx-v6-fra.ninebot.com/user/user/login`: `code = 1`.
5. `POST https://api-jhcx-v6-fra.ninebot.com/vehicle/sound/setting-info` für die vom Nutzer im Mitschnitt referenzierte Seriennummer: **`code = 1`, `desc = Successfully`**. Antwortfelder: `setting_info`, `sound_list`, `max_sound_count`, `max_file_duration`.

Die Passport-API signiert den Pfad, Zeitstempel, gemeinsame Parameter und Requestparameter mit SHA-256 über eine sortierte `key=value`-Zeichenfolge einschließlich des SDK-Clientschlüssels. Zur untersuchten Manifest-Client-ID muss der passende Schlüsselzweig verwendet werden; der zunächst ausprobierte andere Zweig scheiterte an der Signaturprüfung. Clientschlüssel werden hier nicht veröffentlicht.

Beim Fahrzeugaufruf muss `access_token` auch **im verschlüsselten Anfrageinhalt** vorhanden sein. Die App ergänzt es über `BodyParametersProvider`; nur der gleichnamige HTTP-Header genügte in diesem Versuch nicht. Außerdem muss dieselbe `device_id` wie beim Business-Login verwendet werden. Der Versuch mit geänderter Kennung führte zu Code 1005; nach einem regulären Login und anschließender Abfrage mit identischer Kennung gelang die Anfrage.

## Weitere zurückgegebene Werte

- `max_sound_count = 6`.
- `max_file_duration = 600` als Rohwert. Die Einheit ist im untersuchten älteren UI-Modul nicht belegt; daraus werden weder 600 Sekunden noch ein firmwareseitiges Flash-Limit abgeleitet.
- Zwei Einträge in `sound_list`. Persönliche Namen, IDs und URLs dieser Sounds werden nicht exportiert.
- Kein `sys_sound_list`-Feld in dieser konkreten Antwort.

## Export und Grenzen

`g3-sound-server-result.json` enthält die Slot-Metadaten, Statuscodes, SDK-/APK-Hashes und den bereinigten Ablauf. E-Mail-Adresse, UID, Tokens, Refresh-Token, Einmalcode, Gerätekennung, Seriennummer und persönliche Sound-URLs fehlen im Export.

Die Ergebnisse sind an der tatsächlichen Serverantwort für dieses Fahrzeug geprüft. Die Zuordnung von Slot 71 ist zusätzlich durch den Mitschnitt hardwareseitig bestätigt; für Slots 72 und 73 wurde hier kein Upload ausgeführt. Wiedergabe und Persistenz nach Neustart sind keine Ergebnisse dieses Serverversuchs. Die bestehende G3-Connect-App und das GitHub-Exportpaket wurden nicht verändert.
