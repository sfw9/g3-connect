# G3-Soundupload: Auswertung des Bluetooth-Mitschnitts

Stand: 21.10.2026. Die vom Nutzer gelieferte Originaldatei wurde unabhängig vom ebenfalls eingefügten früheren Analyseprotokoll ausgewertet. Es wurden keine Befehle an ein Gerät gesendet und keine App- oder Repositorydateien geändert.

## Ergebnis

Die Kopplung ist enthalten. Alle **1.932 Ninebot-Protokollframes** sind entschlüsselt und verifiziert: **1.924 verschlüsselte Frames mit gültigem MAC**, acht initiale Frames mit gültiger Protokollprüfsumme. Kein extrahierter Protokollframe bleibt unentschlüsselt. Diese Zahlen beziehen sich auf die aus ATT rekonstruierten Ninebot-Frames, nicht auf sämtliche HCI-Pakete.

Der Mitschnitt umfasst **5.638 HCI-Einträge**, 388.970 Byte, keine gekürzten Einträge und keine gemeldeten Drops. ACL/L2CAP- und Protokoll-Reassembly haben keine offenen Fragmente. Aufzeichnungszeit: **21.10.2026, 19:01:20 bis 19:13:09 Uhr Europe/Berlin**. Zeitfelder in den JSON-Dateien verwenden UTC. SHA-256 des Originals: `463902778dc57c4261d7fd94cee19cd31467bfea2acbe28fbeec287f9503cfe5`.

## Kopplung und Entschlüsselung

Es gibt vier PRE_COMM-Sitzungen. Sitzung 3 enthält SET_PWD mit 16 Datenbytes, Power-Bestätigung und erfolgreichen AUTH. Sitzung 4 enthält SET_PWD mit 32 Datenbytes, Power-Bestätigung und erfolgreichen AUTH. Für diese beobachtete 32-Byte-Variante bestätigen die nachfolgenden MACs die ersten 16 Nutzlastbytes als Kopplungsschlüssel; die Bedeutung der zweiten Hälfte wird damit nicht behauptet.

Zwei unterschiedliche Schlüssel lassen sich aus gültig entschlüsselten Kopplungsframes gewinnen. Der in Sitzung 4 erfasste Schlüssel verifiziert auch die zeitlich früheren Sitzungen 1 und 2. Deshalb konnten diese im zweiten Analysedurchlauf ebenfalls vollständig entschlüsselt werden. Der Decoder verwendet keine erratenen Schlüssel. Seriennummer/Gerätename für die initiale Ableitung stammen aus dem vom Nutzer eingefügten Referenztext; die gültigen Initialprüfsummen und nachfolgenden MACs bestätigen diese Eingabe für diese Datei.

Im Download sind Kopplungsnutzlasten, AUTH-/PRE_COMM-Nutzlasten und Seriennummer-Lesedaten ausgeblendet. Die Schlüssel selbst werden weder in den Bericht noch in JSON oder Decoderquelltext geschrieben.

## Drei erfolgreich bestätigte Uploads

| Upload | Sitzung | Ziel / Slot | Uploadbytes | Pakete | Letztes Paket | Audio | Abschlussprüfsumme |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2 | VCU `0x16` / `0x47` (71) | 63.176 | 494 | 72 Byte | 3,945 s | `0xFF9BF048` |
| 2 | 2 | VCU `0x16` / `0x47` (71) | 63.176 | 494 | 72 Byte | 3,945 s | `0xFF9BF048` |
| 3 | 4 | VCU `0x16` / `0x47` (71) | 26.768 | 210 | 16 Byte | 1,6695 s | `0xFFD0A9BF` |

Uploads 1 und 2 sind bytegleich. Alle drei enthalten einen 12-Byte-Vorspann und danach eine vollständige PCM-WAV-Datei mit **8.000 Hz, 16 Bit, einem Kanal**. Die WAV-Dateigrößen ohne Vorspann betragen 63.164 bzw. 26.756 Byte. Slot 71 ist für diese drei Übertragungen belegt. Der Mitschnitt allein ordnet ihn keinem benannten Ereignis wie Einschalten, Ausschalten oder Taste zu und liefert keine vollständige G3-Slottabelle.

## Tatsächlich beobachtete Übertragung des letzten Clips

Frame-Nummern sind nullbasiert und entsprechen `decoded-frames.json`.

1. Frame 1703: VCU-Schreibbefehl `0x03`, Register `0x1F`, Daten `00 00`. Folgende Leseantworten bestätigen `0x0000`. Zuvor war `0x1000` gelesen worden.
2. Frame 1708: Ziel VCU `0x16`, Befehl `0x76`, Index **`0x47`**, Nutzlast `90 68 00 00 01`: angekündigte Uploadlänge 26.768 Byte.
3. Frame 1709: Antwort `0x76`, Statusindex 0, Daten `01 20 00 FF FF FF FF 1E 00 00 00`. Auswertung: Protokollversion 1, **32 Pakete pro Gruppe**, letzter bestätigter Paketindex -1, Wartewert **30 ms**.
4. 210 TX-Pakete mit Befehl `0x77`; jeweils 128 Datenbytes, letzter Abschnitt 16 Byte. Die Indizes laufen je Gruppe ab null. ACKs bestätigen die absoluten Paketindizes 31, 63, 95, 127, 159, 191 und 209 jeweils mit Statusindex 0.
5. Frame 1927: Abschluss `0x78`, **Index 0**, Daten `BF A9 D0 FF`. Das entspricht `~sum(uploadbytes) & 0xFFFFFFFF = 0xFFD0A9BF`.
6. Frame 1928: Antwort `0x78`, Statusindex 0, gleiche Prüfsummendaten. Vom Beginn bis zu dieser Antwort vergehen rund **9,179 Sekunden**.
7. Frame 1929: Schreibbefehl `0x03`, Register `0x1F`, Daten `00 10` = Little-Endian **`0x1000`**. Frame 1931 bestätigt den Wert durch Rücklesen.

Der Upload beginnt mit `0C 00 00 00 90 68 00 00 40 1F 10 01`. Dies bestätigt den zuvor statisch rekonstruierten Vorspann: 12 Byte Headerlänge, gesamte Uploadlänge, Abtastrate 8.000, 16 Bit, ein Kanal.

Register `0x1F` heißt in der untersuchten Gerätekonfiguration `rFunBool3`. Die beobachtete Änderung betrifft Bit 12 (Maske `0x1000`). Dass diese Bitänderung den Upload einrahmt, ist belegt; eine allgemeine Funktionsbezeichnung oder zwingende Notwendigkeit für jede Firmware folgt daraus allein nicht. Es wurde im letzten Sitzungsabschnitt kein weiterer normaler Register-Schreibbefehl außer diesen beiden beobachtet. Uploadbefehle sind davon getrennt gezählt.

## Prüfung und Grenzen

Der Decoder wurde zusätzlich gegen vorhandene unabhängige Gen2-Referenzvektoren für Initialframes, kurze und mehrblockige verschlüsselte Frames geprüft. Veränderte Nutzdaten und veränderte MACs werden abgewiesen. Für alle Uploads wurden angekündigte Längen, Vorspannfelder, RIFF-Längen, Paketindizes, ACK-Positionen und Abschlussprüfsummen überprüft. `validation.txt` enthält den Prüfstand.

Die erfolgreiche Protokollbestätigung belegt die Antwort des im Mitschnitt kommunizierenden Geräts. Die Auswertung bestätigt keine akustische Wiedergabe, keine dauerhafte Speicherung über einen Neustart und keine Kompatibilität mit jeder G3-Firmware. Die Herkunft einzelner Sitzungen aus einer bestimmten Android-App lässt sich aus den HCI-Bytes allein nicht beweisen; die Bezeichnung der letzten Sitzung als Segway stammt aus dem vom Nutzer gelieferten Ablauf.

## Dateien

- `decoded-frames.json`: alle 1.932 entschlüsselten Frames; Kopplungs- und Identitätsdaten ausgeblendet.
- `capture-summary.json`: Zählwerte, Sitzungen, Uploadparameter und ACKs.
- `upload-1.wav`, `upload-2.wav`, `upload-3.wav`: rekonstruierte Audiodateien.
- `upload-1.bin`, `upload-2.bin`, `upload-3.bin`: vollständige Uploadbytes einschließlich des 12-Byte-Vorspanns.
- `analyze_capture.py`: unabhängiger Offline-Decoder; benötigt Python 3.10+ und `pycryptodome`.
- `validation.txt`: ausgeführte Prüfungen.

Aufruf des Decoders: `python analyze_capture.py /pfad/btsnoop_hci.log GERAETENAME_ODER_SERIENNUMMER /pfad/ausgabe`. Es ist dieselbe initiale Namens-/Seriennummer-Eingabe wie im Referenztext erforderlich. Der Decoder führt keine Netzwerk- oder Bluetooth-Zugriffe aus. Die Originalaufzeichnung und der eingefügte Referenztext sind nicht im Ergebnis-ZIP enthalten.
